const fs = require('fs');
const path = require('path');
const songs = require('../database_backups/songs.json');
const artists = require('../database_backups/artists.json');

const vaultDir = path.resolve(__dirname, '../cpsimhz1_complete_vault');
let missingAudios = [];
let missingPosters = [];
let missingStems = [];
let missingArtists = [];

const sanitize = name => (name || '').replace(/[<>:"/\\|?*]/g, '_').trim();

for (const s of songs) {
  const audioName = sanitize(s.title) + ' - ' + sanitize(s.artist) + '.mp3';
  if (!fs.existsSync(path.join(vaultDir, 'songs', audioName))) {
    missingAudios.push({ id: s.id, title: s.title, artist: s.artist, url: s.url });
  }

  const posterJpg = sanitize(s.title) + ' - ' + sanitize(s.artist) + '.jpg';
  const posterPng = sanitize(s.title) + ' - ' + sanitize(s.artist) + '.png';
  if (!fs.existsSync(path.join(vaultDir, 'posters', posterJpg)) && !fs.existsSync(path.join(vaultDir, 'posters', posterPng))) {
    missingPosters.push({ id: s.id, title: s.title, artist: s.artist, poster_url: s.poster_url });
  }

  for (const stem of ['vocals', 'drums', 'bass', 'other']) {
    if (s['stem_' + stem]) {
      const stemFile1 = path.join(vaultDir, 'stems', stem, sanitize(s.title) + ' - ' + sanitize(s.artist) + '.mp3');
      const stemFile2 = path.join(vaultDir, 'stems', sanitize(s.title) + ' - ' + sanitize(s.artist) + ' (' + stem + ').mp3');
      if (!fs.existsSync(stemFile1) && !fs.existsSync(stemFile2)) {
        missingStems.push({ id: s.id, title: s.title, artist: s.artist, stem, url: s['stem_' + stem] });
      }
    }
  }
}

for (const a of artists) {
  if (!a.image_url) continue;
  const aJpg = sanitize(a.name) + '.jpg';
  const aPng = sanitize(a.name) + '.png';
  if (!fs.existsSync(path.join(vaultDir, 'artists', aJpg)) && !fs.existsSync(path.join(vaultDir, 'artists', aPng))) {
    missingArtists.push({ id: a.id, name: a.name, url: a.image_url });
  }
}

console.log('Missing audios count:', missingAudios.length);
console.log('Missing posters count:', missingPosters.length);
console.log('Missing stems count:', missingStems.length);
console.log('Missing artists count:', missingArtists.length);

if (missingAudios.length > 0) console.log('Sample missing audio:', missingAudios.slice(0, 3));
if (missingPosters.length > 0) console.log('Sample missing poster:', missingPosters.slice(0, 3));
if (missingStems.length > 0) console.log('Sample missing stems:', missingStems.slice(0, 3));
if (missingArtists.length > 0) console.log('Sample missing artist:', missingArtists.slice(0, 3));
