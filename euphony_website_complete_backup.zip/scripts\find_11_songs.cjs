const { execSync } = require('child_process');

const songs4ec = JSON.parse(execSync('git show 4ec06f1:database_backups/songs.json', { maxBuffer: 10 * 1024 * 1024 }).toString());
const songs2c = JSON.parse(execSync('git show 2c72938:database_backups/songs.json', { maxBuffer: 10 * 1024 * 1024 }).toString());

const ids2c = new Set(songs2c.map(s => s.id));
const newSongs = songs4ec.filter(s => !ids2c.has(s.id));

console.log('Total new songs found:', newSongs.length);
newSongs.forEach((s, idx) => {
  console.log(`[${idx + 1}] "${s.title}" - ${s.artist} (ID: ${s.id})`);
  console.log('   Audio:', s.url);
  console.log('   Poster:', s.poster_url);
  console.log('   Vocals:', s.stem_vocals);
});
