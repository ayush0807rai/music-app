/**
 * MIGRATE 11 NEW SONGS, ARTISTS, POSTERS, STEMS & LYRICS FROM skqqgkpt TO cpsimhz1
 */

const { execSync } = require('child_process');
const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');
const path = require('path');

const SUPABASE_URL = process.env.VITE_SUPABASE_URL || 'https://gbkaflawosewcrmjkmrt.supabase.co';
const SUPABASE_KEY = process.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_6XDSsjzOs-pig92lW5wvJQ_BYFEzikN';
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

const CPSI_IMAGE_UPLOAD = 'https://api.cloudinary.com/v1_1/cpsimhz1/image/upload';
const CPSI_VIDEO_UPLOAD = 'https://api.cloudinary.com/v1_1/cpsimhz1/video/upload';
const UPLOAD_PRESET = 'app_songs';

async function uploadToCpsimhz1(url, isVideo = false) {
  if (!url || !url.startsWith('http')) return url;
  const endpoint = isVideo ? CPSI_VIDEO_UPLOAD : CPSI_IMAGE_UPLOAD;
  
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const form = new FormData();
      form.append('upload_preset', UPLOAD_PRESET);
      form.append('file', url);

      const res = await fetch(endpoint, {
        method: 'POST',
        body: form
      });

      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Upload failed (${res.status}): ${text}`);
      }

      const json = await res.json();
      return json.secure_url;
    } catch (e) {
      console.warn(`      ⚠️ Attempt ${attempt} failed: ${e.message}`);
      if (attempt < 3) await new Promise(r => setTimeout(r, 2000));
      else throw e;
    }
  }
}

async function run() {
  console.log('=====================================================');
  console.log('🚀 MIGRATING 11 NEW SONGS TO cpsimhz1');
  console.log('=====================================================\n');

  // 1. Get 11 new songs from commit 4ec06f1
  const songs4ec = JSON.parse(execSync('git show 4ec06f1:database_backups/songs.json', { maxBuffer: 10 * 1024 * 1024 }).toString());
  const songs2c = JSON.parse(execSync('git show 2c72938:database_backups/songs.json', { maxBuffer: 10 * 1024 * 1024 }).toString());
  const ids2c = new Set(songs2c.map(s => s.id));
  const newSongs = songs4ec.filter(s => !ids2c.has(s.id));

  // 2. Get 11 new artists from commit 4ec06f1
  const artists4ec = JSON.parse(execSync('git show 4ec06f1:database_backups/artists.json', { maxBuffer: 10 * 1024 * 1024 }).toString());
  const artists2c = JSON.parse(execSync('git show 2c72938:database_backups/artists.json', { maxBuffer: 10 * 1024 * 1024 }).toString());
  const names2c = new Set(artists2c.map(a => a.name));
  const newArtists = artists4ec.filter(a => !names2c.has(a.name));

  console.log(`Found ${newArtists.length} new artists and ${newSongs.length} new songs to add.\n`);

  // --- 3. Migrate New Artists ---
  console.log('--- Step 1: Migrating New Artists ---');
  const migratedArtists = [];
  for (const a of newArtists) {
    let newImg = a.image_url;
    if (a.image_url && a.image_url.includes('skqqgkpt')) {
      console.log(`   🎨 Uploading artist image for: ${a.name}...`);
      newImg = await uploadToCpsimhz1(a.image_url, false);
      console.log(`      ✅ Uploaded to cpsimhz1: ${newImg}`);
    }
    migratedArtists.push({
      ...a,
      image_url: newImg
    });
  }

  // Insert artists into Supabase
  for (const a of migratedArtists) {
    const { error } = await supabase.from('artists').upsert(a, { onConflict: 'name' });
    if (error) console.error(`Error saving artist ${a.name}:`, error.message);
  }
  console.log(`✅ ${migratedArtists.length} artists saved to Supabase!\n`);

  // --- 4. Migrate New Songs ---
  console.log('--- Step 2: Migrating 11 Songs (Audio, Posters, Stems, Lyrics) ---');
  const migratedSongs = [];
  for (let i = 0; i < newSongs.length; i++) {
    const s = newSongs[i];
    console.log(`\n[${i + 1}/${newSongs.length}] 🎵 Processing "${s.title}" - ${s.artist}`);

    // Master audio
    console.log('   📤 Uploading master audio to cpsimhz1...');
    const audioUrl = await uploadToCpsimhz1(s.url, true);
    console.log(`      ✅ Audio: ${audioUrl}`);

    // Poster
    console.log('   🖼️ Uploading poster image to cpsimhz1...');
    const posterUrl = await uploadToCpsimhz1(s.poster_url, false);
    console.log(`      ✅ Poster: ${posterUrl}`);

    // Stems
    let stemVocals = s.stem_vocals;
    let stemDrums = s.stem_drums;
    let stemBass = s.stem_bass;
    let stemOther = s.stem_other;

    if (s.stem_vocals) {
      console.log('   🎤 Uploading vocals stem to cpsimhz1...');
      stemVocals = await uploadToCpsimhz1(s.stem_vocals, true);
    }
    if (s.stem_drums) {
      console.log('   🥁 Uploading drums stem to cpsimhz1...');
      stemDrums = await uploadToCpsimhz1(s.stem_drums, true);
    }
    if (s.stem_bass) {
      console.log('   🎸 Uploading bass stem to cpsimhz1...');
      stemBass = await uploadToCpsimhz1(s.stem_bass, true);
    }
    if (s.stem_other) {
      console.log('   🎹 Uploading other/instruments stem to cpsimhz1...');
      stemOther = await uploadToCpsimhz1(s.stem_other, true);
    }
    console.log('      ✅ All 4 stems uploaded to cpsimhz1!');

    migratedSongs.push({
      ...s,
      url: audioUrl,
      poster_url: posterUrl,
      stem_vocals: stemVocals,
      stem_drums: stemDrums,
      stem_bass: stemBass,
      stem_other: stemOther,
      needs_stems: false
    });
  }

  // Insert songs into Supabase
  console.log('\n--- Step 3: Saving Migrated Songs to Supabase ---');
  for (const s of migratedSongs) {
    const { error } = await supabase.from('songs').upsert(s, { onConflict: 'id' });
    if (error) console.error(`Error saving song ${s.title}:`, error.message);
  }
  console.log(`✅ All ${migratedSongs.length} new songs saved to Supabase!\n`);

  // --- 5. Update Local database_backups JSON files ---
  console.log('--- Step 4: Updating Local Database Backups ---');
  const currentArtistsPath = path.join(__dirname, '../database_backups/artists.json');
  const currentSongsPath = path.join(__dirname, '../database_backups/songs.json');

  const fullArtists = [...artists2c, ...migratedArtists];
  const fullSongs = [...songs2c, ...migratedSongs];

  fs.writeFileSync(currentArtistsPath, JSON.stringify(fullArtists, null, 2), 'utf8');
  fs.writeFileSync(currentSongsPath, JSON.stringify(fullSongs, null, 2), 'utf8');

  console.log(`✅ Updated database_backups/artists.json (${fullArtists.length} total)`);
  console.log(`✅ Updated database_backups/songs.json (${fullSongs.length} total)`);

  console.log('\n=====================================================');
  console.log('🎉 MIGRATION COMPLETED SUCCESSFULLY!');
  console.log('=====================================================');
}

run().catch(err => {
  console.error('❌ Migration failed:', err);
  process.exit(1);
});
